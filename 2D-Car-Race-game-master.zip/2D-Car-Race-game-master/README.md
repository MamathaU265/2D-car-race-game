# C++ 2D-Car-Race-game
OpenGL and C++ 2D Car Race game With GLUT library

IDE: Code::Blocks

2d Car Racing Game computer graphics OpenGL Project.
A simple car race game, i made for my Computer Graphics cource LAB project in c++ with OpenGL  and GLUT library.

![screenshot_35](https://user-images.githubusercontent.com/33642700/32984276-9ce05748-cccd-11e7-800c-e3b2493570d7.png)

## Project Video in YouTube :
[![OpenGL and C++ 2D Car Race game With GLUT library](https://img.youtube.com/vi/nZbLqcoet4I/0.jpg)](https://www.youtube.com/watch?v=nZbLqcoet4I)
